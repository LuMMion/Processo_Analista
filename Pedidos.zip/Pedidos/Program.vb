
Imports System.Windows.Forms

Module Program
    <STAThread>
    Sub Main()
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)

        Dim repo As New PedidoRepositoryJson()
        Dim service As New PedidoService(repo)
        Dim form As New FormPedido(service)
        Application.Run(form)
    End Sub
End Module


'Module Program
'    Public Sub Main()
'        Application.EnableVisualStyles()
'        Application.SetCompatibleTextRenderingDefault(False)

'        ' Aqui voc� pode instanciar o reposit�rio e o servi�o, se quiser
'        ' Dim repo As New PedidoRepository()
'        ' Dim servico As New PedidoService(repo)

'        ' Inicializa o formul�rio principal
'        Application.Run(New FormPedido())
'    End Sub
'End Module
