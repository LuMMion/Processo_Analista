# Projeto: VendaPedidos (VB.NET - Windows Forms)

## Objetivo
Módulo de pedidos com as funcionalidades de:
- Efetuar Pedido
- Cancelar Pedido
- Listar pedidos ativos

## Funcionalidades Atendidas
✔ Não permite pedidos inválidos  
✔ Garante atomicidade ao salvar no JSON  
✔ Mantém histórico dos pedidos  
✔ Lista apenas pedidos ativos  
✔ Permite cancelamento sem excluir o pedido

## Estrutura de Pastas

VendaPedidos_JSON_Corrigido/
│
├── Domain/
│   ├── Pedido.vb (entidade)
│   └── IPedidoRepository.vb (interface de repositório)
│
├── Repository/
│   └── PedidoRepository.vb (implementação JSON)
│
├── Service/
│   ├── IPedidoService.vb (interface de serviço)
│   └── PedidoService.vb (regras de negócio)
│
├── UI/
│   └── FormPedido.vb (formulário Windows Forms)
│
├── Module1.vb (ponto de entrada com Sub Main)
└── VendaPedidos.vbproj

## Execução

- A aplicação é iniciada pelo Module1.vb (Sub Main)
- O formulário FormPedido é carregado com o serviço de pedidos
- Os dados são salvos e carregados de 'pedidos.json'

## Tecnologias
- VB.NET (.NET Framework 4.8)
- Windows Forms
- Persistência em arquivo JSON
- Padrões SOLID e DDD
