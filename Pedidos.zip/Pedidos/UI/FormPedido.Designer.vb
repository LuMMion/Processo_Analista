
Partial Class FormPedido
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer
    Private txtDescricao As TextBox
    Private txtQuantidade As TextBox
    Private txtPreco As TextBox
    Private txtId As TextBox
    'Private BtnEfetuar As Button
    'Private BtnCancelar As Button
    Private WithEvents BtnEfetuar As Button
    Private WithEvents BtnCancelar As Button

    Private DgvPedidos As DataGridView

    Private Sub InitializeComponent()
        txtDescricao = New TextBox()
        txtQuantidade = New TextBox()
        txtPreco = New TextBox()
        txtId = New TextBox()
        BtnEfetuar = New Button()
        BtnCancelar = New Button()
        DgvPedidos = New DataGridView()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        BtnSair = New Button()
        CType(DgvPedidos, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtDescricao
        ' 
        txtDescricao.Location = New Point(161, 12)
        txtDescricao.Name = "txtDescricao"
        txtDescricao.PlaceholderText = "Descrição"
        txtDescricao.Size = New Size(241, 31)
        txtDescricao.TabIndex = 0
        ' 
        ' txtQuantidade
        ' 
        txtQuantidade.Location = New Point(161, 49)
        txtQuantidade.Name = "txtQuantidade"
        txtQuantidade.PlaceholderText = "Quantidade"
        txtQuantidade.Size = New Size(100, 31)
        txtQuantidade.TabIndex = 1
        ' 
        ' txtPreco
        ' 
        txtPreco.Location = New Point(161, 86)
        txtPreco.Name = "txtPreco"
        txtPreco.PlaceholderText = "Preço Unitário"
        txtPreco.Size = New Size(100, 31)
        txtPreco.TabIndex = 2
        ' 
        ' txtId
        ' 
        txtId.Location = New Point(161, 129)
        txtId.Name = "txtId"
        txtId.PlaceholderText = "ID para Cancelamento"
        txtId.Size = New Size(100, 31)
        txtId.TabIndex = 3
        ' 
        ' BtnEfetuar
        ' 
        BtnEfetuar.Location = New Point(466, 13)
        BtnEfetuar.Name = "BtnEfetuar"
        BtnEfetuar.Size = New Size(162, 31)
        BtnEfetuar.TabIndex = 4
        BtnEfetuar.Text = "Efetuar Pedido"
        ' 
        ' BtnCancelar
        ' 
        BtnCancelar.Location = New Point(466, 61)
        BtnCancelar.Name = "BtnCancelar"
        BtnCancelar.Size = New Size(162, 31)
        BtnCancelar.TabIndex = 5
        BtnCancelar.Text = "Cancelar Pedido"
        ' 
        ' DgvPedidos
        ' 
        DgvPedidos.ColumnHeadersHeight = 34
        DgvPedidos.Location = New Point(12, 166)
        DgvPedidos.Name = "DgvPedidos"
        DgvPedidos.RowHeadersWidth = 62
        DgvPedidos.Size = New Size(616, 200)
        DgvPedidos.TabIndex = 6
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(13, 13)
        Label1.Name = "Label1"
        Label1.Size = New Size(77, 25)
        Label1.TabIndex = 7
        Label1.Text = "Produto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(13, 49)
        Label2.Name = "Label2"
        Label2.Size = New Size(105, 25)
        Label2.TabIndex = 8
        Label2.Text = "Quantidade"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(13, 86)
        Label3.Name = "Label3"
        Label3.Size = New Size(123, 25)
        Label3.TabIndex = 9
        Label3.Text = "Preço Unitario"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(13, 129)
        Label4.Name = "Label4"
        Label4.Size = New Size(33, 25)
        Label4.TabIndex = 10
        Label4.Text = "Id "
        ' 
        ' BtnSair
        ' 
        BtnSair.Location = New Point(466, 113)
        BtnSair.Name = "BtnSair"
        BtnSair.Size = New Size(162, 31)
        BtnSair.TabIndex = 11
        BtnSair.Text = "Sair"
        BtnSair.UseVisualStyleBackColor = True
        ' 
        ' FormPedido
        ' 
        ClientSize = New Size(647, 400)
        Controls.Add(BtnSair)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtDescricao)
        Controls.Add(txtQuantidade)
        Controls.Add(txtPreco)
        Controls.Add(txtId)
        Controls.Add(BtnEfetuar)
        Controls.Add(BtnCancelar)
        Controls.Add(DgvPedidos)
        Name = "FormPedido"
        Text = "Sistema de Pedidos"
        CType(DgvPedidos, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BtnSair As Button
End Class
