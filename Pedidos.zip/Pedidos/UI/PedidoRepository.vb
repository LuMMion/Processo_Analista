﻿Public Class PedidoRepository
    Implements IPedidoRepository

    Public Sub Salvar(pedido As Pedido) Implements IPedidoRepository.Salvar
        ' Implementação da gravação (JSON, CSV, etc.)
    End Sub

    Public Function ObterTodos() As List(Of Pedido) Implements IPedidoRepository.ObterTodos
        ' Retorna os pedidos do arquivo
        Return New List(Of Pedido)()
    End Function

    Public Sub CancelarPedido(id As Guid) Implements IPedidoRepository.CancelarPedido
        ' Lógica para cancelar pedido
    End Sub

    Public Sub Salvar(pedidos As List(Of Pedido)) Implements IPedidoRepository.Salvar
        Throw New NotImplementedException()
    End Sub
End Class
