
Public Class FormPedido
    Private ReadOnly _service As IPedidoService


    Public Sub New(service As IPedidoService)
        InitializeComponent()
        _service = service
    End Sub

    Private Sub btnEfetuar_Click(sender As Object, e As EventArgs) Handles BtnEfetuar.Click
        Try
            Dim descricao = txtDescricao.Text
            Dim quantidade = Integer.Parse(txtQuantidade.Text)
            Dim preco = Decimal.Parse(txtPreco.Text)

            _service.EfetuarPedido(descricao, quantidade, preco)
            MessageBox.Show("Pedido efetuado com sucesso.")
            AtualizarGrid()
        Catch ex As Exception
            MessageBox.Show("Erro: " & ex.Message)
        End Try
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles BtnCancelar.Click
        Try
            Dim id = Guid.Parse(txtId.Text)
            _service.CancelarPedido(id)
            MessageBox.Show("Pedido cancelado com sucesso.")
            AtualizarGrid()
        Catch ex As Exception
            MessageBox.Show("Erro: " & ex.Message)
        End Try
    End Sub

    Private Sub AtualizarGrid()
        DgvPedidos.DataSource = _service.ListarPedidosAtivos()
    End Sub

    Private Sub BtnSair_Click(sender As Object, e As EventArgs) Handles BtnSair.Click
        Me.Close()
    End Sub
End Class
