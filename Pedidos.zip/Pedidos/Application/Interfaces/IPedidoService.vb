
Public Interface IPedidoService
    Sub EfetuarPedido(descricao As String, qtd As Integer, preco As Decimal, v As Object)
    Sub CancelarPedido(id As Guid)
    Sub EfetuarPedido(descricao As String, qtd As Integer, preco As Decimal)
    Function ListarPedidosAtivos() As List(Of Pedido)
End Interface

