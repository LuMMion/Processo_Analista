
Public Class PedidoService
    Implements IPedidoService

    Private ReadOnly _repositorio As IPedidoRepository
    Private ReadOnly _estoqueProdutos As Dictionary(Of String, Integer)

    Public Sub New(repo As IPedidoRepository)
        _repositorio = repo
        _estoqueProdutos = New Dictionary(Of String, Integer) From {
            {"Teclado", 10}, {"Mouse", 20}, {"Monitor", 5}
        }
    End Sub

    Public Sub EfetuarPedido(descricao As String, qtd As Integer, preco As Decimal, v As Object) Implements IPedidoService.EfetuarPedido
        Dim value As Integer = Nothing

        If Not _estoqueProdutos.TryGetValue(descricao, value) Then
            Throw New PedidoException("Produto inexistente.")
        End If

        If qtd > value Then
            Throw New PedidoException("Quantidade indispon�vel em estoque.")
        End If

        Dim pedidos = _repositorio.ObterTodos()
        Dim novo = New Pedido With {
            .Id = Guid.NewGuid(),
            .Descricao = descricao,
            .Quantidade = qtd,
            .PrecoUnitario = preco,
            .Data = DateTime.Now,
            .Status = StatusPedido.Ativo
        }

        _estoqueProdutos(descricao) -= qtd
        pedidos.Add(novo)
        _repositorio.Salvar(pedidos)
    End Sub

    Public Sub EfetuarPedido(descricao As String, qtd As Integer, preco As Decimal) Implements IPedidoService.EfetuarPedido
        Throw New NotImplementedException()
    End Sub

    Public Sub CancelarPedido(id As Guid) Implements IPedidoService.CancelarPedido
        Dim pedidos = _repositorio.ObterTodos()
        Dim pedido = pedidos.FirstOrDefault(Function(p) p.Id = id)

        If pedido Is Nothing Then Throw New PedidoException("Pedido n�o encontrado.")

        pedido.Cancelar()
        _repositorio.Salvar(pedidos)
    End Sub

    Public Function ListarPedidosAtivos() As List(Of Pedido) Implements IPedidoService.ListarPedidosAtivos
        Return _repositorio.ObterTodos().Where(Function(p) p.Status = StatusPedido.Ativo).ToList()
    End Function

    'Public Function Get_repositorio() As Object Implements IPedidoService.Get_repositorio
    '    Throw New NotImplementedException()
    'End Function
End Class
