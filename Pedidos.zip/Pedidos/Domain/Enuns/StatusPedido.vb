
Public Enum StatusPedido
    Ativo
    Cancelado
End Enum
