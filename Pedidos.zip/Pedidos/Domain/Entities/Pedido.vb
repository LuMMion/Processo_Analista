
Public Class Pedido
    Public Property Id As Guid
    Public Property Descricao As String
    Public Property Quantidade As Integer
    Public Property PrecoUnitario As Decimal
    Public Property Data As DateTime
    Public Property Status As StatusPedido

    Public ReadOnly Property Total As Decimal
        Get
            Return Quantidade * PrecoUnitario
        End Get
    End Property

    Public Sub Cancelar()
        If Status = StatusPedido.Cancelado Then
            Throw New PedidoException("Pedido já está cancelado.")
        End If
        Status = StatusPedido.Cancelado
    End Sub
End Class
