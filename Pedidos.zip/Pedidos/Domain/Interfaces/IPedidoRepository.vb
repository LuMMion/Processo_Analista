

Public Interface IPedidoRepository
    Function ObterTodos() As List(Of Pedido)
    Sub Salvar(pedidos As List(Of Pedido))
    Sub Salvar(pedido As Pedido)
    Sub CancelarPedido(id As Guid)
End Interface
