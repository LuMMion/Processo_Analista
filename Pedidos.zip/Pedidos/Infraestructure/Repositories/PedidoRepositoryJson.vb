
Imports System.IO
Imports Newtonsoft.Json

Public Class PedidoRepositoryJson
    Implements IPedidoRepository

    Private ReadOnly _path As String = "Base de Dados/pedidos.json"
    Private ReadOnly _lock As New Object()

    Public Function ObterTodos() As List(Of Pedido) Implements IPedidoRepository.ObterTodos
        SyncLock _lock
            If Not File.Exists(_path) Then Return New List(Of Pedido)
            Dim json = File.ReadAllText(_path)
            Return JsonConvert.DeserializeObject(Of List(Of Pedido))(json)
        End SyncLock
    End Function

    Public Sub Salvar(pedidos As List(Of Pedido)) Implements IPedidoRepository.Salvar
        SyncLock _lock
            Dim json = JsonConvert.SerializeObject(pedidos, Formatting.Indented)
            File.WriteAllText(_path, json)
        End SyncLock
    End Sub

    Public Sub Salvar(pedido As Pedido) Implements IPedidoRepository.Salvar
        Throw New NotImplementedException()
    End Sub

    Public Sub CancelarPedido(id As Guid) Implements IPedidoRepository.CancelarPedido
        Throw New NotImplementedException()
    End Sub
End Class
